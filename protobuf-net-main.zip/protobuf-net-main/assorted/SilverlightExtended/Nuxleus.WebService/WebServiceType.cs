﻿namespace Nuxleus.WebService {
    public enum WebServiceType {
        SOAP,
        REST,
        QUERY
    }
}
